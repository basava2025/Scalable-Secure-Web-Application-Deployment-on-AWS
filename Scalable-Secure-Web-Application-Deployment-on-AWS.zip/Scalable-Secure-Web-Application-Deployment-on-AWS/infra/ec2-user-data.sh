#!/bin/bash
# EC2 user data script